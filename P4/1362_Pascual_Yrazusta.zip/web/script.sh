virtualenv -p python3 si1pyenv
source si1pyenv/bin/activate
pip3 install Flask SQLAlchemy Flask-SQLAlchemy SQLAlchemy-Utils psycopg2 itsdangerous Flask-Session
python3 -m app
deactivate